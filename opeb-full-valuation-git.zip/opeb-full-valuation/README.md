# OPEB Full Valuation Engine

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GASB 75 Compliant](https://img.shields.io/badge/GASB%2075-Compliant-green.svg)](https://www.gasb.org/)

Production-ready GASB 75 OPEB valuation engine implementing Entry Age Normal (EAN) actuarial cost method with comprehensive per-member liability calculations.

## Features

- **Entry Age Normal Cost Method** per GASB 75 ¶162
- **Multiple Decrement Tables (MDT)** with O(1) tensor lookups
- **Pub-2010 Mortality** with Scale MP-2021 generational projection
- **Vectorized Calculations** for performance
- **GASB 75 Disclosure Generator** for automated footnote tables
- **Comprehensive Test Suite** with actuarial validation tests

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/opeb-full-valuation.git
cd opeb-full-valuation
pip install -e .
```

## Quick Start

```python
from opeb_valuation import ValuationEngine, create_engine
from datetime import date

config = {
    'valuation_date': date(2025, 9, 30),
    'discount_rate': 0.0381,
    'discount_rate_boy': 0.0409,
    'mortality_load': 1.20,
}

engine = create_engine(config)
results = engine.run_valuation(actives_df, retirees_df)

print(f"Total OPEB Liability: ${results['TOL'].sum():,.0f}")
print(f"Service Cost: ${results['ServiceCost'].sum():,.0f}")
```

## Modules

| Module | Description |
|--------|-------------|
| `engine.py` | Core valuation engine with EAN attribution |
| `mortality.py` | Pub-2010 tables with MP-2021 projection |
| `decrements.py` | Termination, disability, retirement rates |
| `financials.py` | Discount factors, trend models, morbidity |
| `gasb_disclosure.py` | Automated GASB 75 footnote table generator |

## Compliance

- GASB Statement No. 75
- GASB Implementation Guide No. 2017-3
- ASOP 4: Measuring Pension Obligations
- ASOP 6: Measuring Retiree Group Benefits Obligations
- ASOP 25: Credibility Procedures
- ASOP 35: Selection of Demographic Assumptions

## Testing

```bash
pytest tests/ -v
```

## License

MIT License - See LICENSE file for details.

## Disclaimer

This software is provided for educational and professional use. Actuarial valuations for official reporting should be reviewed by a qualified actuary.
